document.addEventListener("DOMContentLoaded", () => {
  const predefinedResponses = {
    "hello": "Hi there! How can I assist you today?",
    "how are you": "I'm just a bot, but I'm here to help!",
    "what is your name": "I'm your friendly Language Translation Chatbot!",
    "bye": "Goodbye! Have a great day!",
    "tell me about the college": "Here are the details of PBR VITS:",
    "show me personal details": "Here are the predefined personal details:"
  };

  const predefinedTranslations = {
    "hello": {
      "te": "హలో",
      "hi": "नमस्ते",
      "ta": "வணக்கம்",
      "ur": "ہیلو",
      "bn": "হ্যালো"
    }
  };

  const aboutUsData = {
    collegeName: "PBR Visvodaya Institute of Technology and Science",
    mission:
      "To provide quality teaching-learning practices in engineering and management education by imparting core instruction and state-of-the-art infrastructure.",
    vision:
      "To be a premier centre of learning in Engineering and Management education that evolves the youth into dynamic professionals with a social commitment.",
    about:
      "PBR VITS is furnished with well-equipped laboratories, classrooms with audio-visual aids, R&D labs, and Wi-Fi Facility. In addition, the institution has provided adequately for all amenities such as hostels, canteen, transport, and sports facilities."
  };

  const personalDetails = [
    {
      name: "B. SushmaSwaraj",
      email: "sushmabujja@gmail.com",
      phone: "9959810215",
      address: "Podalakuru, Nellore, India",
      about:
        "Myself Sushma, I am studying BTech 3rd year in PBR VITS. I am so happy to be in this college."
    },
    {
      name: "K. Varnitha Oliviya",
      email: "varnithaoliviya@gmail.com",
      phone: "9123456789",
      address: "Atmakur, Andhra Pradesh, India",
      about:
        "I am pursuing BTech 4th year at PBR VITS and interested in research and development."
    },
    {
      name: "U.Niharika",
      email: "niharika@gmail.com",
      phone: "9911223344",
      address: "Kavali, Andhra Pradesh, India",
      about:
        "A final-year engineering student specializing in Electronics and Communication."
    },
    {
      name: "K.Manasa",
      email: "Manas@gmail.com",
      phone: "9900112233",
      address: "Tirupati, Andhra Pradesh, India",
      about:
        "An aspiring entrepreneur with a keen interest in software development."
    },
    {
      name: "D. Vaishanavi",
      email: "vaishu@gmail.com",
      phone: "9877898765",
      address: "Kavali, Andhra Pradesh, India",
      about:
        "A creative thinker and designer in the field of Computer Science."
    }
  ];

  const startChatBtn = document.getElementById("init");
  const closeBtn = document.querySelector(".close-btn");
  const chatbox = document.querySelector(".chatbox");
  const chatInput = document.querySelector(".chat-input textarea");
  const sendChatBtn = document.querySelector(".send-btn");
  const languageSelector = document.querySelector("#language-selector");
  const speechBtn = document.querySelector(".mic-btn");

  let userMessage = "";
  const inputInitHeight = chatInput.scrollHeight;

  // API configuration
  const API_KEY = "AIzaSyAr4EUW3Vf9LfcLFhKALPpgZMc4iRoSScQ";
  const AI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${API_KEY}`;
  const TRANSLATE_API = "https://api.mymemory.translated.net/get";

  startChatBtn?.addEventListener("click", () => document.body.classList.add("show-chatbot"));
  closeBtn?.addEventListener("click", () => document.body.classList.remove("show-chatbot"));

  const createChatMessage = (message, className) => {
    const chatMessage = document.createElement("li");
    chatMessage.classList.add("chat", className);
    chatMessage.innerHTML = `<p>${message}</p>`;
    return chatMessage;
  };

  const translateText = async (text, targetLang) => {
    try {
      const chunkSize = 400;
      let translatedText = "";

      for (let i = 0; i < text.length; i += chunkSize) {
        const chunk = text.substring(i, i + chunkSize);
        const response = await fetch(
          `${TRANSLATE_API}?q=${encodeURIComponent(chunk)}&langpair=en|${targetLang}`
        );
        const data = await response.json();
        translatedText += data.responseData.translatedText + " ";
      }

      return translatedText.trim();
    } catch (error) {
      console.error("Translation Error:", error);
      return "Could not translate the text.";
    }
  };

  const sendAIRequest = async (content) => {
    try {
      const response = await fetch(AI_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: content }] }]
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error.message);
      return data.candidates[0].content.parts[0].text || "I'm not sure how to respond.";
    } catch (error) {
      console.error("AI Request Error:", error);
      return "AI request failed.";
    }
  };

  const generateResponse = async (chatElement) => {
    const messageElement = chatElement.querySelector("p");
    try {
      const predefinedResponse = predefinedResponses[userMessage.toLowerCase()];

      if (predefinedResponse) {
        if (userMessage.toLowerCase() === "tell me about the college") {
          const responseText =
            `<strong>${aboutUsData.collegeName}</strong><br>` +
            `<strong>Mission:</strong> ${aboutUsData.mission}<br>` +
            `<strong>Vision:</strong> ${aboutUsData.vision}<br>` +
            `<strong>About:</strong> ${aboutUsData.about}`;
          messageElement.innerHTML = responseText;
          speakText(aboutUsData.collegeName + ". Mission: " + aboutUsData.mission + ". Vision: " + aboutUsData.vision + ". About: " + aboutUsData.about);
        } else if (userMessage.toLowerCase() === "show me personal details") {
          const responseText = personalDetails
            .map(person =>
              `<strong>Name:</strong> ${person.name}<br>` +
              `<strong>Email:</strong> ${person.email}<br>` +
              `<strong>Phone:</strong> ${person.phone}<br>` +
              `<strong>Address:</strong> ${person.address}<br>` +
              `<strong>About:</strong> ${person.about}<br><br>`
            )
            .join("");
          messageElement.innerHTML = responseText;
          speakText("Here are the personal details of the listed individuals.");
        } else {
          messageElement.textContent = predefinedResponse;
          speakText(predefinedResponse);
        }
      } else {
        const selectedLang = languageSelector.value || "en";
        const botResponse = await sendAIRequest(userMessage);
        const translatedResponse = await translateText(botResponse, selectedLang);

        messageElement.innerHTML = `<strong>English:</strong> ${botResponse} <br><strong>${languageSelector.options[languageSelector.selectedIndex].text}:</strong> ${translatedResponse}`;
        speakText(botResponse);
      }
    } catch (error) {
      messageElement.classList.add("error");
      messageElement.textContent = `Error: ${error.message}`;
    } finally {
      chatbox.scrollTo(0, chatbox.scrollHeight);
    }
  };

  const handleChat = () => {
    userMessage = chatInput.value.trim().toLowerCase();
    if (!userMessage) return;
    chatInput.value = "";
    chatInput.style.height = `${inputInitHeight}px`;

    chatbox.appendChild(createChatMessage(userMessage, "outgoing"));
    chatbox.scrollTo(0, chatbox.scrollHeight);

    setTimeout(() => {
      const incomingChat = createChatMessage("Thinking...", "incoming");
      chatbox.appendChild(incomingChat);
      chatbox.scrollTo(0, chatbox.scrollHeight);
      generateResponse(incomingChat);
    }, 600);
  };

  // Text-to-Speech (TTS) functionality
  const speakText = (text) => {
    const utterance = new SpeechSynthesisUtterance(text);
    speechSynthesis.speak(utterance);
  };

  // Speech-to-Text (STT) functionality
  const startSpeechToText = () => {
    if (!("webkitSpeechRecognition" in window)) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    const recognition = new webkitSpeechRecognition();
      recognition.lang = "en-US";
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onresult = (event) => {
          const transcript = event.results[0][0].transcript;
          chatInput.value = transcript;
          chatInput.focus();
      };
    recognition.onerror = (event) => {
      console.error("Speech Recognition Error:", event.error);
  };

  recognition.onend = () => {
      console.log("Speech recognition ended.");
  };

  recognition.start();
};

// Attach STT functionality to the microphone button
speechBtn.addEventListener("click", startSpeechToText);

sendChatBtn.addEventListener("click", handleChat);
});
